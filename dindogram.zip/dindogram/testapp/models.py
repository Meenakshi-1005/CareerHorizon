from django.db import models

class GovtSectorJob(models.Model):
    sno = models.AutoField(primary_key=True)
    sector=models.CharField(max_length=50,default='unknown')
    job_title = models.CharField(max_length=200)
    description = models.TextField()
    qualification = models.CharField(max_length=200)

    def _str_(self):
        return f"S.No: {self.sno}, Job Title: {self.job_title}, Description: {self.description}, Qualification: {self.qualification}"

class NonGovtSectorJob(models.Model):
    sno = models.AutoField(primary_key=True)
    industry_type = models.CharField(max_length=200)
    department = models.CharField(max_length=200)
    role_category = models.CharField(max_length=200)
    key_skills = models.CharField(max_length=300)
    role = models.CharField(max_length=200)
    description = models.TextField()

    def _str_(self):
        return (f"S.No: {self.sno}, Industry Type: {self.industry_type}, Department: {self.department}, "
                f"Role Category: {self.role_category}, Key Skills: {self.key_skills}, Role: {self.role}, "
                f"Description: {self.description}")